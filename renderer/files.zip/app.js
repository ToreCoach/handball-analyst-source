// ============================================================
// HANDBALL ANALYST — renderer
// ============================================================

function formatTime(sec) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = Math.floor(sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function debounce(fn, ms) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
}

// -------------------------------------------------------
// Pannello tag riusabile: costruisce bottoni dal DB, gestisce selezione
// -------------------------------------------------------
async function caricaPannelloTag(container, onToggle, selezionati) {
  const categorie = await window.api.getTags();
  container.innerHTML = '';

  categorie.forEach(cat => {
    const blocco = document.createElement('div');
    blocco.className = `categoria-blocco gruppo-${cat.gruppo || 'generale'}`;

    if (cat.tag.length === 0) {
      // categoria vuota: il titolo stesso funge da flag rapido (es. "Attacco"/"Difesa"
      // senza sottovoci) — al primo click materializza un tag reale e lo seleziona
      const titolo = document.createElement('button');
      titolo.type = 'button';
      titolo.className = 'categoria-titolo-flag';
      titolo.textContent = `✓ ${cat.nome.toUpperCase()}`;
      titolo.addEventListener('click', async () => {
        const tagId = await window.api.creaOTrovaTagCategoria(cat.id);
        if (!tagId) return;
        if (selezionati.has(tagId)) { selezionati.delete(tagId); titolo.classList.remove('selezionato'); }
        else { selezionati.add(tagId); titolo.classList.add('selezionato'); }
        if (onToggle) onToggle();
      });
      blocco.appendChild(titolo);
      container.appendChild(blocco);
      return;
    }

    const titolo = document.createElement('h3');
    titolo.textContent = cat.nome.toUpperCase();
    blocco.appendChild(titolo);

    const lista = document.createElement('div');
    lista.className = 'tag-lista';

    cat.tag.forEach(nodo => renderizzaNodoTag(nodo, lista, onToggle, selezionati));

    blocco.appendChild(lista);
    container.appendChild(blocco);
  });
}

// Renderizza UN nodo dell'albero tag: se è una cartella, un'intestazione
// espandibile con i figli annidati dentro (a qualsiasi profondità); se è
// una voce foglia, un bottone cliccabile normale come prima.
function renderizzaNodoTag(nodo, contenitore, onToggle, selezionati) {
  if (nodo.e_cartella) {
    const cartella = document.createElement('div');
    cartella.className = 'tag-cartella';

    const header = document.createElement('button');
    header.type = 'button';
    header.className = 'tag-cartella-header';
    header.innerHTML = `<span class="chevron">▾</span> 📁 ${nodo.nome}`;

    const figli = document.createElement('div');
    figli.className = 'tag-cartella-figli';

    header.addEventListener('click', () => {
      const chiusa = figli.style.display === 'none';
      figli.style.display = chiusa ? 'flex' : 'none';
      header.querySelector('.chevron').textContent = chiusa ? '▾' : '▸';
    });

    nodo.children.forEach(figlio => renderizzaNodoTag(figlio, figli, onToggle, selezionati));

    cartella.appendChild(header);
    cartella.appendChild(figli);
    contenitore.appendChild(cartella);
    return;
  }

  const btn = document.createElement('button');
  btn.className = 'tag-btn';
  btn.textContent = nodo.nome;
  btn.dataset.tagId = nodo.id;
  if (nodo.colore) btn.style.borderColor = nodo.colore;

  btn.addEventListener('click', () => {
    if (selezionati.has(nodo.id)) { selezionati.delete(nodo.id); btn.classList.remove('selezionato'); }
    else { selezionati.add(nodo.id); btn.classList.add('selezionato'); }
    if (onToggle) onToggle();
  });

  contenitore.appendChild(btn);
}

// ============================================================
// VISTA ANALISI: import partita + tagging live con Z (inizio) / M (fine)
// ============================================================
const player = document.getElementById('player');
const videoTitle = document.getElementById('videoTitle');
const categorieContainer = document.getElementById('categorie');
const btnApri = document.getElementById('btnApri');
const btnSalvaTag = document.getElementById('btnSalvaTag');
const tempoCorrente = document.getElementById('tempoCorrente');
const catturaStato = document.getElementById('catturaStato');

let tagSelezionati = new Set();
let partitaCorrenteId = null;
let inizioCatturato = null;
let fineCatturata = null;
let squadraCasaCorrente = null;   // { id, nome }
let squadraOspiteCorrente = null; // { id, nome }
let squadraRiferimentoSelezionata = null; // sticky: resta selezionata tra un evento e l'altro
let giocatoreSelezionato = null;  // NON sticky: si azzera dopo ogni salvataggio

caricaPannelloTag(categorieContainer, null, tagSelezionati);

player.addEventListener('timeupdate', () => {
  tempoCorrente.textContent = `${formatTime(player.currentTime)} / ${formatTime(player.duration || 0)}`;
});

// --- Nuova partita ---
const modalNP = document.getElementById('modalNuovaPartita');
const npVideoScelto = document.getElementById('npVideoScelto');
let videoSelezionatoPath = null;

btnApri.addEventListener('click', () => modalNP.classList.add('active'));
document.getElementById('npAnnulla').addEventListener('click', () => modalNP.classList.remove('active'));

document.getElementById('npSelezionaVideo').addEventListener('click', async () => {
  const filePath = await window.api.selezionaVideo();
  if (!filePath) return;
  videoSelezionatoPath = filePath;
  npVideoScelto.textContent = filePath.split('/').pop();
});

document.getElementById('npCrea').addEventListener('click', async () => {
  const casa = document.getElementById('npCasa').value.trim();
  const ospite = document.getElementById('npOspite').value.trim();
  const data = document.getElementById('npData').value;
  const stagioneLabel = document.getElementById('npStagione').value.trim();
  const competizione = document.getElementById('npCompetizione').value.trim();

  if (!casa || !ospite || !videoSelezionatoPath) {
    alert('Squadra casa, squadra ospite e video sono obbligatori.');
    return;
  }

  const squadraCasaId = await window.api.creaOTrovaSquadra(casa);
  const squadraOspiteId = await window.api.creaOTrovaSquadra(ospite);
  const stagioneId = stagioneLabel ? await window.api.creaOTrovaStagione(stagioneLabel) : null;

  const nuovaPartitaId = await window.api.creaPartita({
    squadra_casa_id: squadraCasaId, squadra_ospite_id: squadraOspiteId,
    data: data || null, stagione_id: stagioneId, competizione: competizione || null,
    video_path: videoSelezionatoPath
  });

  modalNP.classList.remove('active');

  apriPartitaInAnalisi({
    id: nuovaPartitaId,
    video_path: videoSelezionatoPath,
    squadra_casa_id: squadraCasaId, squadra_casa: casa,
    squadra_ospite_id: squadraOspiteId, squadra_ospite: ospite,
    n_eventi: 0
  });
});

// Apre una partita (nuova o già esistente) nel player di Analisi: video,
// squadre di riferimento, e indicatore eventi già salvati
async function apriPartitaInAnalisi(p) {
  partitaCorrenteId = p.id;
  player.src = `file://${p.video_path}`;
  videoTitle.textContent = `${p.squadra_casa} - ${p.squadra_ospite}`;

  squadraCasaCorrente = { id: p.squadra_casa_id, nome: p.squadra_casa };
  squadraOspiteCorrente = { id: p.squadra_ospite_id, nome: p.squadra_ospite };
  squadraRiferimentoSelezionata = null;
  giocatoreSelezionato = null;
  renderizzaSquadreRiferimento();

  inizioCatturato = null;
  fineCatturata = null;
  aggiornaStatoCattura();

  const nota = document.getElementById('eventiSalvatiNota');
  if (p.n_eventi > 0) {
    nota.style.display = 'block';
    nota.innerHTML = `📌 ${p.n_eventi} eventi già salvati per questa partita — <a id="linkVediEventiAnalisi">vedili in Eventi</a>`;
    document.getElementById('linkVediEventiAnalisi').addEventListener('click', () => {
      document.querySelector('nav button[data-view="eventi"]').click();
      apriPartitaInEventi(p.id, `${p.squadra_casa} - ${p.squadra_ospite}`, null, p.squadra_casa, p.squadra_ospite);
    });
  } else {
    nota.style.display = 'none';
  }
}

// --- Apri partita esistente ---
const modalApriPartita = document.getElementById('modalApriPartita');

document.getElementById('btnApriEsistente').addEventListener('click', async () => {
  const partite = await window.api.elencoPartiteConConteggi();
  const cont = document.getElementById('elencoApriPartita');
  cont.innerHTML = '';

  if (partite.length === 0) {
    cont.innerHTML = '<p style="color:var(--muted); font-size:13px;">Nessuna partita ancora creata.</p>';
  }

  partite.forEach(p => {
    const riga = document.createElement('div');
    riga.className = 'apri-partita-riga';
    riga.innerHTML = `<span>${p.squadra_casa} - ${p.squadra_ospite}</span><span class="conteggio">${p.n_eventi} eventi</span>`;
    riga.addEventListener('click', () => {
      apriPartitaInAnalisi(p);
      modalApriPartita.classList.remove('active');
    });
    cont.appendChild(riga);
  });

  modalApriPartita.classList.add('active');
});

document.getElementById('apriPartitaAnnulla').addEventListener('click', () => modalApriPartita.classList.remove('active'));

// --- Riferimento squadra (sticky) + rosa selezionabile (non sticky) ---
const riferimentoSquadraEl = document.getElementById('riferimentoSquadra');
const squadraButtonsEl = document.getElementById('squadraButtons');
const giocatoreButtonsEl = document.getElementById('giocatoreButtons');

function renderizzaSquadreRiferimento() {
  riferimentoSquadraEl.style.display = 'block';
  squadraButtonsEl.innerHTML = '';

  [squadraCasaCorrente, squadraOspiteCorrente].forEach(sq => {
    const btn = document.createElement('button');
    btn.className = 'squadra-btn';
    btn.textContent = sq.nome;
    if (squadraRiferimentoSelezionata && squadraRiferimentoSelezionata.id === sq.id) btn.classList.add('selezionato');
    btn.addEventListener('click', () => selezionaSquadraRiferimento(sq, btn));
    squadraButtonsEl.appendChild(btn);
  });

  if (squadraRiferimentoSelezionata) caricaRosaGiocatoreButtons(squadraRiferimentoSelezionata.id);
  else giocatoreButtonsEl.innerHTML = '';
}

async function selezionaSquadraRiferimento(sq, btnEl) {
  squadraRiferimentoSelezionata = sq;
  giocatoreSelezionato = null;
  document.querySelectorAll('.squadra-btn').forEach(b => b.classList.remove('selezionato'));
  btnEl.classList.add('selezionato');
  await caricaRosaGiocatoreButtons(sq.id);
}

async function caricaRosaGiocatoreButtons(squadraId) {
  const giocatori = await window.api.elencoGiocatoriPerSquadra(squadraId);
  giocatoreButtonsEl.innerHTML = '';

  giocatori.forEach(g => {
    const btn = document.createElement('button');
    btn.className = 'giocatore-btn';
    btn.textContent = `${g.numero ? g.numero + ' · ' : ''}${g.nome} ${g.cognome || ''}`.trim();
    btn.addEventListener('click', () => {
      const eraSelezionato = giocatoreSelezionato === g.id;
      document.querySelectorAll('.giocatore-btn').forEach(b => b.classList.remove('selezionato'));
      giocatoreSelezionato = eraSelezionato ? null : g.id;
      if (!eraSelezionato) btn.classList.add('selezionato');
    });
    giocatoreButtonsEl.appendChild(btn);
  });
}

// --- Cattura Z (inizio) / M (fine) ---
function aggiornaStatoCattura() {
  if (inizioCatturato === null) {
    catturaStato.textContent = "Premi Z per segnare l'inizio di un evento, M per la fine.";
    catturaStato.classList.remove('attiva');
    btnSalvaTag.disabled = true;
  } else if (fineCatturata === null) {
    catturaStato.textContent = `Evento iniziato a ${formatTime(inizioCatturato)} — premi M per chiudere.`;
    catturaStato.classList.add('attiva');
    btnSalvaTag.disabled = true;
  } else {
    catturaStato.textContent = `Evento ${formatTime(inizioCatturato)} → ${formatTime(fineCatturata)}: scegli i tag e salva.`;
    catturaStato.classList.add('attiva');
    btnSalvaTag.disabled = false;
  }
}

// Fase di CATTURA (terzo parametro true): intercetta Z/M prima che il player
// video nativo li gestisca lui stesso (es. M = muto, un tasto riservato dai
// controlli HTML5 quando il video ha il focus).
window.addEventListener('keydown', (e) => {
  if (e.key !== 'z' && e.key !== 'Z' && e.key !== 'm' && e.key !== 'M') return;
  if (e.repeat) return; // ignora l'auto-repeat se il tasto resta premuto
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
  if (!document.getElementById('view-analisi').classList.contains('active')) return;
  if (!partitaCorrenteId) return;

  e.preventDefault();
  e.stopImmediatePropagation(); // nessun altro listener può intercettare/rallentare questo tasto

  if (e.key === 'z' || e.key === 'Z') {
    inizioCatturato = player.currentTime;
    fineCatturata = null;
    aggiornaStatoCattura();
  }
  if (e.key === 'm' || e.key === 'M') {
    if (inizioCatturato === null) return;
    fineCatturata = Math.max(player.currentTime, inizioCatturato + 0.2);
    player.pause(); // tempo per taggare con calma
    aggiornaStatoCattura();
  }
}, true);

// Frecce ← → = avanti/indietro di 5 secondi, durante l'analisi della gara
window.addEventListener('keydown', (e) => {
  if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
  if (!document.getElementById('view-analisi').classList.contains('active')) return;
  if (!partitaCorrenteId) return;

  e.preventDefault();
  e.stopImmediatePropagation();

  const delta = e.key === 'ArrowRight' ? 5 : -5;
  player.currentTime = Math.max(0, Math.min(player.duration || Infinity, player.currentTime + delta));
}, true);

btnSalvaTag.addEventListener('click', async () => {
  if (inizioCatturato === null || fineCatturata === null) return;

  await window.api.creaEvento({
    partita_id: partitaCorrenteId,
    inizio_sec: inizioCatturato,
    fine_sec: fineCatturata,
    squadra_riferimento_id: squadraRiferimentoSelezionata ? squadraRiferimentoSelezionata.id : null,
    giocatore_id: giocatoreSelezionato,
    note: null,
    tagIds: Array.from(tagSelezionati)
  });

  tagSelezionati.clear();
  document.querySelectorAll('#categorie .tag-btn.selezionato').forEach(b => b.classList.remove('selezionato'));

  // il giocatore NON è sticky: si azzera. La squadra di riferimento invece resta
  // selezionata (sticky) per l'evento successivo, come richiesto.
  giocatoreSelezionato = null;
  document.querySelectorAll('.giocatore-btn.selezionato').forEach(b => b.classList.remove('selezionato'));

  inizioCatturato = null;
  fineCatturata = null;
  aggiornaStatoCattura();
  document.getElementById('statoSalvataggio').textContent = 'Evento salvato';
});

aggiornaStatoCattura();

// ============================================================
// SWITCH VISTE
// ============================================================
document.querySelectorAll('nav button[data-view]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('nav button[data-view]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById(`view-${btn.dataset.view}`).classList.add('active');

    if (btn.dataset.view === 'partite') caricaArchivio();
    if (btn.dataset.view === 'eventi') caricaVistaEventi();
    if (btn.dataset.view === 'presentazioni') caricaVistaPresentazioni();
    if (btn.dataset.view === 'giocatori') caricaVistaGiocatori();
    if (btn.dataset.view === 'statistiche') caricaVistaImpostazioni(); // ora ospita Gestione Tag
    if (btn.dataset.view === 'impostazioni') caricaVistaImpostazioniApp();
    if (btn.dataset.view === 'analisi') caricaPannelloTag(categorieContainer, null, tagSelezionati); // rispecchia eventuali modifiche fatte in Statistiche
  });
});

// ============================================================
// VISTA PARTITE (archivio con filtri)
// ============================================================
const selStagione = document.getElementById('filtroStagione');
const selSquadra = document.getElementById('filtroSquadra');
const selCompetizione = document.getElementById('filtroCompetizione');
const selAvversario = document.getElementById('filtroAvversario');
const inputRicerca = document.getElementById('filtroRicerca');

let opzioniFiltriCaricate = false;

async function caricaArchivio() {
  if (!opzioniFiltriCaricate) {
    const opzioni = await window.api.opzioniFiltriArchivio();
    opzioni.stagioni.forEach(s => selStagione.add(new Option(s.label, s.id)));
    opzioni.squadre.forEach(s => { selSquadra.add(new Option(s.nome, s.id)); selAvversario.add(new Option(s.nome, s.id)); });
    opzioni.competizioni.forEach(c => selCompetizione.add(new Option(c, c)));
    [selStagione, selSquadra, selCompetizione, selAvversario].forEach(sel => sel.addEventListener('change', eseguiRicercaArchivio));
    inputRicerca.addEventListener('input', debounce(eseguiRicercaArchivio, 300));
    opzioniFiltriCaricate = true;
  }
  eseguiRicercaArchivio();
}

async function eseguiRicercaArchivio() {
  const { partite, totali } = await window.api.elencoPartite({
    stagione_id: selStagione.value || null,
    squadra_id: selSquadra.value || null,
    competizione: selCompetizione.value || null,
    avversario_id: selAvversario.value || null,
    ricerca: inputRicerca.value || null
  });

  document.getElementById('archivioTotali').innerHTML = `
    <span><b>${totali.partite}</b>partite</span>
    <span><b>${totali.eventi}</b>eventi</span>
    <span><b>${totali.tiri}</b>tiri</span>
    <span><b>${totali.gol}</b>gol</span>
  `;

  const lista = document.getElementById('archivioLista');
  lista.innerHTML = '';
  partite.forEach(p => {
    const riga = document.createElement('div');
    riga.className = 'partita-riga';
    riga.innerHTML = `<span>${p.squadra_casa} - ${p.squadra_ospite}</span><span class="n-eventi">${p.n_eventi} eventi · seleziona →</span>`;
    riga.addEventListener('click', () => {
      document.querySelector('nav button[data-view="eventi"]').click();
      apriPartitaInEventi(p.id, `${p.squadra_casa} - ${p.squadra_ospite}`, null, p.squadra_casa, p.squadra_ospite);
    });
    lista.appendChild(riga);
  });
}

// ============================================================
// VISTA EVENTI: partite -> eventi -> seleziona -> importa in presentazione
// ============================================================
const eventiElencoPartite = document.getElementById('eventiElencoPartite');
const eventiPartitaTitolo = document.getElementById('eventiPartitaTitolo');
const eventiTabella = document.getElementById('eventiTabella');
const btnImportaPresentazione = document.getElementById('btnImportaPresentazione');

let partiteCaricateInEventi = false;
let partitaApertaInEventiId = null;
let eventiPartitaCorrente = [];
let eventiSelezionati = new Set();
let ordinaPerCategorieIds = []; // in ordine di click: [primario, secondario, ...]
let categorieDisponibiliEventi = [];

async function caricaVistaEventi() {
  if (!partiteCaricateInEventi) {
    const partite = await window.api.elencoPartiteConConteggi();
    eventiElencoPartite.innerHTML = '';
    partite.forEach(p => {
      const riga = document.createElement('div');
      riga.className = 'eventi-partita-riga';
      riga.innerHTML = `${p.squadra_casa} - ${p.squadra_ospite}<span class="conteggio">${p.n_eventi} eventi</span>`;
      riga.addEventListener('click', () => apriPartitaInEventi(p.id, `${p.squadra_casa} - ${p.squadra_ospite}`, riga, p.squadra_casa, p.squadra_ospite));
      eventiElencoPartite.appendChild(riga);
    });
    categorieDisponibiliEventi = await window.api.elencoCategorie();
    renderizzaOrdinaCategorie();
    partiteCaricateInEventi = true;
  }
}

function renderizzaOrdinaCategorie() {
  const cont = document.getElementById('eventiOrdinaCategorie');
  cont.innerHTML = '';

  categorieDisponibiliEventi.forEach(cat => {
    const btn = document.createElement('button');
    const posizione = ordinaPerCategorieIds.indexOf(cat.id);
    btn.className = 'gruppo-btn gruppo-' + (cat.gruppo || 'generale') + (posizione !== -1 ? ' selezionato' : '');
    btn.textContent = posizione !== -1 ? `${cat.nome} ${posizione + 1}°` : cat.nome;

    btn.addEventListener('click', (e) => {
      const giaPresente = ordinaPerCategorieIds.includes(cat.id);

      if (e.shiftKey) {
        // shift: aggiunge o toglie un criterio di ordinamento secondario, senza toccare gli altri
        if (giaPresente) ordinaPerCategorieIds = ordinaPerCategorieIds.filter(id => id !== cat.id);
        else ordinaPerCategorieIds.push(cat.id);
      } else {
        // click semplice: diventa l'UNICO criterio (o si spegne se era già l'unico)
        ordinaPerCategorieIds = (giaPresente && ordinaPerCategorieIds.length === 1) ? [] : [cat.id];
      }

      renderizzaOrdinaCategorie();
      renderizzaTabellaEventi();
    });

    cont.appendChild(btn);
  });
}

let filtroSquadraEventi = '';

async function apriPartitaInEventi(partitaId, titolo, rigaEl, squadraCasa, squadraOspite) {
  document.querySelectorAll('.eventi-partita-riga').forEach(r => r.classList.remove('attiva'));
  if (rigaEl) rigaEl.classList.add('attiva');

  partitaApertaInEventiId = partitaId;
  eventiPartitaTitolo.textContent = titolo;
  eventiSelezionati.clear();
  btnImportaPresentazione.disabled = true;
  filtroSquadraEventi = '';

  renderizzaFiltroSquadraEventi(squadraCasa, squadraOspite);

  eventiPartitaCorrente = await window.api.elencoEventiPerPartita(partitaId);
  renderizzaTabellaEventi();
}

function renderizzaFiltroSquadraEventi(squadraCasa, squadraOspite) {
  const cont = document.getElementById('eventiFiltroSquadra');
  cont.innerHTML = '';
  if (!squadraCasa && !squadraOspite) return;

  const opzioni = [{ nome: '', label: 'Tutte le squadre' }, { nome: squadraCasa, label: squadraCasa }, { nome: squadraOspite, label: squadraOspite }];
  opzioni.forEach(o => {
    const btn = document.createElement('button');
    btn.className = 'gruppo-btn' + (o.nome === '' ? ' selezionato' : '');
    btn.textContent = o.label;
    btn.addEventListener('click', () => {
      cont.querySelectorAll('.gruppo-btn').forEach(b => b.classList.remove('selezionato'));
      btn.classList.add('selezionato');
      filtroSquadraEventi = o.nome;
      renderizzaTabellaEventi();
    });
    cont.appendChild(btn);
  });
}

// Ordina per una o più categorie (in priorità di click): per ogni evento,
// usa la posizione (ordine) del tag che ha in quella categoria; chi non ha
// nessun tag in quella categoria scivola in fondo. A parità totale, resta
// l'ordine manuale originale (il sort di JS è stabile).
function ordinaEventiPerCategorie(eventi, categorieIds) {
  if (categorieIds.length === 0) return eventi;
  return [...eventi].sort((a, b) => {
    for (const catId of categorieIds) {
      const tagA = a.tag.find(t => t.categoria_id === catId);
      const tagB = b.tag.find(t => t.categoria_id === catId);
      const ordA = tagA ? tagA.tag_ordine : Infinity;
      const ordB = tagB ? tagB.tag_ordine : Infinity;
      if (ordA !== ordB) return ordA - ordB;
    }
    return 0;
  });
}

function renderizzaTabellaEventi() {
  let filtrati = eventiPartitaCorrente;
  if (filtroSquadraEventi) {
    filtrati = filtrati.filter(ev => ev.squadra_riferimento_nome === filtroSquadraEventi);
  }
  filtrati = ordinaEventiPerCategorie(filtrati, ordinaPerCategorieIds);

  eventiTabella.innerHTML = '';
  filtrati.forEach((ev, i) => {
    const riga = document.createElement('div');
    riga.className = 'eventi-riga';
    const badge = ev.tag.map(t => `<span class="tag-badge">${t.nome}</span>`).join('');
    const chiSquadra = ev.squadra_riferimento_nome ? `<span class="tag-badge">${ev.squadra_riferimento_nome}</span>` : '';
    const chiGiocatore = ev.giocatore_nome ? `<span class="tag-badge">${ev.giocatore_nome} ${ev.giocatore_cognome || ''}</span>` : '';

    riga.innerHTML = `
      <span class="ordina-gruppo">
        <button class="ordina-btn ordina-su" ${i === 0 ? 'disabled' : ''} title="Sposta su">▲</button>
        <button class="ordina-btn ordina-giu" ${i === filtrati.length - 1 ? 'disabled' : ''} title="Sposta giù">▼</button>
      </span>
      <input type="checkbox" data-evento-id="${ev.id}">
      <span class="tempo">${formatTime(ev.inizio_sec)}-${formatTime(ev.fine_sec)}</span>
      <span>${chiSquadra}${chiGiocatore}${badge}</span>
    `;
    riga.querySelector('input').addEventListener('change', (e) => {
      if (e.target.checked) eventiSelezionati.add(ev.id); else eventiSelezionati.delete(ev.id);
      btnImportaPresentazione.disabled = eventiSelezionati.size === 0;
    });

    riga.querySelector('.ordina-su').addEventListener('click', async () => {
      if (i === 0) return;
      await window.api.scambiaOrdineEventi({ eventoIdA: ev.id, eventoIdB: filtrati[i - 1].id });
      eventiPartitaCorrente = await window.api.elencoEventiPerPartita(partitaApertaInEventiId);
      renderizzaTabellaEventi();
    });
    riga.querySelector('.ordina-giu').addEventListener('click', async () => {
      if (i === filtrati.length - 1) return;
      await window.api.scambiaOrdineEventi({ eventoIdA: ev.id, eventoIdB: filtrati[i + 1].id });
      eventiPartitaCorrente = await window.api.elencoEventiPerPartita(partitaApertaInEventiId);
      renderizzaTabellaEventi();
    });

    eventiTabella.appendChild(riga);
  });
}

// --- Importa in presentazione (riusabile: vista Eventi + pannello Giocatore) ---
const modalImp = document.getElementById('modalImportaPresentazione');
const impPresentazioneEsistente = document.getElementById('impPresentazioneEsistente');
const impNuovaPresentazione = document.getElementById('impNuovaPresentazione');

let sorgenteImportCorrente = null; // { eventiSet, dopoImport() }

function apriModaleImporta(sorgente) {
  sorgenteImportCorrente = sorgente;
  window.api.elencoPresentazioni().then(presentazioni => {
    impPresentazioneEsistente.innerHTML = '<option value="">— nessuna —</option>';
    presentazioni.forEach(p => impPresentazioneEsistente.add(new Option(p.nome, p.id)));
    impNuovaPresentazione.value = '';
    modalImp.classList.add('active');
  });
}

btnImportaPresentazione.addEventListener('click', () => {
  apriModaleImporta({
    eventiSet: eventiSelezionati,
    dopoImport: () => { btnImportaPresentazione.disabled = true; renderizzaTabellaEventi(); }
  });
});

document.getElementById('impAnnulla').addEventListener('click', () => modalImp.classList.remove('active'));

document.getElementById('impConferma').addEventListener('click', async () => {
  if (!sorgenteImportCorrente) return;
  const presentazioneId = impPresentazioneEsistente.value || null;
  const nomeNuova = impNuovaPresentazione.value.trim();

  if (!presentazioneId && !nomeNuova) { alert('Scegli una presentazione esistente o dai un nome a quella nuova.'); return; }

  const { eventiSet, dopoImport } = sorgenteImportCorrente;

  await window.api.aggiungiEventiAPresentazione({
    presentazioneId: presentazioneId ? Number(presentazioneId) : null,
    nomeNuovaPresentazione: nomeNuova || null,
    eventoIds: Array.from(eventiSet)
  });

  modalImp.classList.remove('active');
  document.getElementById('statoSalvataggio').textContent = `${eventiSet.size} eventi importati in presentazione`;
  eventiSet.clear();
  if (dopoImport) dopoImport();
});

// ============================================================
// VISTA PRESENTAZIONI: editor durata + disegni + export
// ============================================================
const elencoPresentazioniEl = document.getElementById('elencoPresentazioni');
const presentazioneTitolo = document.getElementById('presentazioneTitolo');
const presentazioneClipLista = document.getElementById('presentazioneClipLista');
const presentazioneVideo = document.getElementById('presentazioneVideo');
const trimInizio = document.getElementById('trimInizio');
const trimFine = document.getElementById('trimFine');

let presentazioneApertaId = null;
let clipPresentazioneCorrente = [];
let clipSelezionataId = null;

async function caricaVistaPresentazioni() {
  // rete di sicurezza: ricalcola le dimensioni del canvas ora che il riquadro
  // è visibile e il video ha la sua dimensione CSS definitiva
  window.dispatchEvent(new Event('resize'));

  const presentazioni = await window.api.elencoPresentazioni();
  elencoPresentazioniEl.innerHTML = '';
  presentazioni.forEach(p => {
    const riga = document.createElement('div');
    riga.className = 'playlist-riga';
    riga.textContent = p.nome;
    riga.addEventListener('click', () => apriPresentazione(p.id, p.nome, riga));
    elencoPresentazioniEl.appendChild(riga);
  });
}

async function apriPresentazione(id, nome, rigaEl) {
  document.querySelectorAll('#elencoPresentazioni .playlist-riga').forEach(r => r.classList.remove('attiva'));
  if (rigaEl) rigaEl.classList.add('attiva');

  presentazioneApertaId = id;
  presentazioneTitolo.textContent = nome;
  clipPresentazioneCorrente = await window.api.clipPresentazione(id);
  renderizzaListaClipPresentazione();
  if (clipPresentazioneCorrente.length > 0) apriClipPresentazione(clipPresentazioneCorrente[0]);
}

function renderizzaListaClipPresentazione() {
  presentazioneClipLista.innerHTML = '';
  clipPresentazioneCorrente.forEach((c, i) => {
    const riga = document.createElement('div');
    riga.className = 'pres-clip-riga';
    riga.textContent = `${i + 1}. ${c.squadra_casa} - ${c.squadra_ospite}`;
    if (c.id === clipSelezionataId) riga.classList.add('attiva');
    riga.addEventListener('click', () => apriClipPresentazione(c, riga));
    presentazioneClipLista.appendChild(riga);
  });
}

let ultimoPausaSec = null; // momento in cui il coach ha messo in pausa per disegnare, per QUESTA clip
let pausaAutoTriggerata = false; // evita che l'auto-pausa in rivisione scatti più volte sullo stesso passaggio

function apriClipPresentazione(c) {
  document.querySelectorAll('.pres-clip-riga').forEach(r => r.classList.remove('attiva'));
  clipSelezionataId = c.id;
  renderizzaListaClipPresentazione();

  const inizio = c.inizio_sec ?? c.evento_inizio_sec;
  const fine = c.fine_sec ?? c.evento_fine_sec;

  // fermo il video PRIMA di cambiare sorgente: se era rimasto "in riproduzione"
  // da prima (es. dopo Salva clip), altrimenti riparte da solo appena pronto
  // e cancella subito i disegni appena caricati
  presentazioneVideo.pause();
  presentazioneVideo.src = `file://${c.video_path}`;
  presentazioneVideo.addEventListener('loadedmetadata', function alSeek() {
    presentazioneVideo.pause();
    presentazioneVideo.currentTime = inizio;
    presentazioneVideo.removeEventListener('loadedmetadata', alSeek);
  });

  trimInizio.value = inizio.toFixed(1);
  trimFine.value = fine.toFixed(1);

  // parto sempre con nessuno strumento attivo: i controlli video restano usabili subito
  document.querySelectorAll('.disegno-tool').forEach(b => b.classList.remove('selezionato'));
  Disegno.impostaStrumento(null);
  Disegno.caricaForme(c.disegni_json || null);

  ultimoPausaSec = c.pausa_timestamp_sec ?? null;
  pausaAutoTriggerata = false; // ogni riapertura può far scattare di nuovo la pausa automatica in riproduzione
  document.getElementById('pausaDurata').value = c.pausa_durata_sec ?? 3;
  aggiornaStatoPausa();
}

function aggiornaStatoPausa() {
  const stato = document.getElementById('pausaStato');
  const btnRimuovi = document.getElementById('btnRimuoviPausa');
  if (ultimoPausaSec != null) {
    stato.textContent = `Pausa impostata a ${formatTime(ultimoPausaSec)} — nel video esportato il fotogramma resterà fermo lì con i disegni`;
    btnRimuovi.style.display = 'inline';
  } else {
    stato.textContent = 'Nessuna pausa impostata per questa clip (metti in pausa il video per impostarla)';
    btnRimuovi.style.display = 'none';
  }
}

document.getElementById('btnRimuoviPausa').addEventListener('click', () => {
  ultimoPausaSec = null;
  aggiornaStatoPausa();
});

document.getElementById('btnSalvaClip').addEventListener('click', async () => {
  if (!clipSelezionataId) return;
  const pausaDurata = Number(document.getElementById('pausaDurata').value) || 3;

  await window.api.aggiornaClipPresentazione({
    id: clipSelezionataId,
    inizio_sec: Number(trimInizio.value),
    fine_sec: Number(trimFine.value),
    disegni_json: Disegno.ottieniFormeJSON(),
    pausa_timestamp_sec: ultimoPausaSec,
    pausa_durata_sec: pausaDurata
  });

  // ricarico dal database (non solo aggiorno a mano la copia in memoria):
  // cosí i disegni salvati non possono più disallinearsi da quello che vedi
  // se riapri questa clip più tardi nella stessa sessione
  clipPresentazioneCorrente = await window.api.clipPresentazione(presentazioneApertaId);

  document.getElementById('statoSalvataggio').textContent = 'Clip salvata';

  // l'azione riparte: il listener 'play' del video pulisce da solo i disegni
  // dalla preview (restano comunque salvati per l'export)
  presentazioneVideo.play();
});

document.getElementById('btnRimuoviClip').addEventListener('click', async () => {
  if (!clipSelezionataId) return;
  if (!confirm('Rimuovere questa clip dalla presentazione?')) return;
  await window.api.rimuoviClipPresentazione(clipSelezionataId);
  clipPresentazioneCorrente = clipPresentazioneCorrente.filter(c => c.id !== clipSelezionataId);
  clipSelezionataId = null;
  renderizzaListaClipPresentazione();
  if (clipPresentazioneCorrente.length > 0) apriClipPresentazione(clipPresentazioneCorrente[0]);
  else { presentazioneVideo.removeAttribute('src'); Disegno.caricaForme(null); }
});

document.getElementById('btnEsportaPresentazione').addEventListener('click', async () => {
  if (!presentazioneApertaId) { alert('Apri prima una presentazione.'); return; }
  if (clipPresentazioneCorrente.length === 0) { alert('La presentazione non ha clip.'); return; }

  const btn = document.getElementById('btnEsportaPresentazione');
  btn.textContent = 'Esportazione in corso...';
  btn.disabled = true;

  // se la clip aperta ha modifiche non salvate, le salvo prima di esportare
  if (clipSelezionataId) {
    await window.api.aggiornaClipPresentazione({
      id: clipSelezionataId,
      inizio_sec: Number(trimInizio.value),
      fine_sec: Number(trimFine.value),
      disegni_json: Disegno.ottieniFormeJSON(),
      pausa_timestamp_sec: ultimoPausaSec,
      pausa_durata_sec: Number(document.getElementById('pausaDurata').value) || 3
    });
  }

  // rigenero l'elenco aggiornato e preparo gli overlay PNG per le clip che hanno disegni
  clipPresentazioneCorrente = await window.api.clipPresentazione(presentazioneApertaId);
  const overlayPngPerClip = {};

  for (const c of clipPresentazioneCorrente) {
    if (!c.disegni_json) continue;
    Disegno.caricaForme(c.disegni_json);
    const dataUrl = Disegno.generaPngPerExport();
    if (dataUrl) overlayPngPerClip[c.id] = await window.api.scriviPngTemp(dataUrl);
  }

  // ripristino sul canvas i disegni della clip attualmente aperta
  if (clipSelezionataId) {
    const attuale = clipPresentazioneCorrente.find(c => c.id === clipSelezionataId);
    Disegno.caricaForme(attuale ? attuale.disegni_json : null);
  }

  const risultato = await window.api.esportaPresentazione({ presentazioneId: presentazioneApertaId, overlayPngPerClip });

  btn.textContent = '⬇ Esporta come MP4';
  btn.disabled = false;
  if (risultato) alert(`Esportato in: ${risultato}`);
});

// --- Toolbar disegno (percorsi, cerchi, triangoli, testo, fascio luce) ---
// --- "Disegna" dedicato: funziona SEMPRE, anche con uno strumento di
// disegno attivo (il canvas sopra il video blocca i controlli nativi quando
// è in modalità disegno — questo pulsante vive fuori dal canvas). Blocca il
// fotogramma; quando l'azione riparte (da qualunque comando: play nativo,
// barra spazio, o Salva clip), i disegni spariscono dalla preview — restano
// comunque salvati per l'export una volta premuto Salva clip. ---
const btnDisegnaFreeze = document.getElementById('btnDisegnaFreeze');

btnDisegnaFreeze.addEventListener('click', () => {
  presentazioneVideo.pause();
});

presentazioneVideo.addEventListener('play', () => {
  Disegno.cancellaTutto();
});
presentazioneVideo.addEventListener('pause', () => {
  // registro il punto di pausa (solo se il video ha già riprodotto qualcosa,
  // per non scattare al semplice caricamento della clip)
  if (presentazioneVideo.currentTime > 0) {
    ultimoPausaSec = presentazioneVideo.currentTime;
    aggiornaStatoPausa();
    pausaAutoTriggerata = true; // evita che riprendendo scatti subito un'altra auto-pausa nello stesso punto
  }
});

// Rivedendo una clip già salvata: quando la riproduzione raggiunge il punto
// di pausa registrato, si ferma da sola, richiama i disegni salvati e li
// tiene a schermo per la durata scelta, poi riparte da sola (i disegni
// spariscono di nuovo grazie al listener 'play' qui sopra).
presentazioneVideo.addEventListener('timeupdate', () => {
  if (presentazioneVideo.paused) return;
  if (ultimoPausaSec == null) return;
  if (pausaAutoTriggerata) return;
  if (presentazioneVideo.currentTime < ultimoPausaSec) return;

  pausaAutoTriggerata = true;
  presentazioneVideo.pause();

  const c = clipPresentazioneCorrente.find(x => x.id === clipSelezionataId);
  Disegno.caricaForme(c ? c.disegni_json : null);

  const durataMs = (Number(document.getElementById('pausaDurata').value) || 3) * 1000;
  setTimeout(() => { presentazioneVideo.play(); }, durataMs);
});

// Riavvolgendo prima del punto di pausa, l'auto-pausa può scattare di nuovo
// al prossimo passaggio in avanti
presentazioneVideo.addEventListener('seeked', () => {
  if (ultimoPausaSec != null && presentazioneVideo.currentTime < ultimoPausaSec - 0.05) {
    pausaAutoTriggerata = false;
  }
});

// barra spaziatrice = play/pausa, anche mentre disegni (ma non mentre scrivi un testo)
window.addEventListener('keydown', (e) => {
  if (!document.getElementById('view-presentazioni').classList.contains('active')) return;
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
  if (e.code !== 'Space') return;
  e.preventDefault();
  if (presentazioneVideo.paused) presentazioneVideo.play();
  else presentazioneVideo.pause();
}, true);

// frecce ← → = avanti/indietro di 5 secondi, anche in Presentazioni
window.addEventListener('keydown', (e) => {
  if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
  if (!document.getElementById('view-presentazioni').classList.contains('active')) return;
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;

  e.preventDefault();
  e.stopImmediatePropagation();

  const delta = e.key === 'ArrowRight' ? 5 : -5;
  presentazioneVideo.currentTime = Math.max(0, Math.min(presentazioneVideo.duration || Infinity, presentazioneVideo.currentTime + delta));
}, true);

Disegno.init(presentazioneVideo, document.getElementById('disegnoCanvas'), {
  stileIniziale: { colore: '#ff3b30', spessore: 4 }
});

document.querySelectorAll('.disegno-tool').forEach(btn => {
  btn.addEventListener('click', () => {
    const eraAttivo = btn.classList.contains('selezionato');
    document.querySelectorAll('.disegno-tool').forEach(b => b.classList.remove('selezionato'));

    if (eraAttivo) {
      // riclicco lo stesso strumento: lo spengo, così il video torna cliccabile
      Disegno.impostaStrumento(null);
      return;
    }

    btn.classList.add('selezionato');
    Disegno.impostaStrumento(btn.dataset.tool);
    document.getElementById('disegnoCanvas').style.cursor = btn.dataset.tool === 'seleziona' ? 'grab' : 'crosshair';
  });
});

function aggiornaStileDaToolbar() {
  Disegno.impostaStile({
    colore: document.getElementById('optColore').value,
    spessore: Number(document.getElementById('optSpessore').value),
    curva: document.getElementById('optCurva').checked,
    tratteggiata: document.getElementById('optTratteggiata').checked,
    freccia: document.getElementById('optFreccia').checked,
    font: document.getElementById('optFont').value,
    coloreTesto: document.getElementById('optTestoColoreTesto').value,
    sfondoTesto: document.getElementById('optTestoColoreSfondo').value,
    sfondoTestoAttivo: document.getElementById('optTestoSfondoAttivo').checked
  });
}
['optColore', 'optSpessore', 'optCurva', 'optTratteggiata', 'optFreccia', 'optFont',
 'optTestoColoreTesto', 'optTestoColoreSfondo', 'optTestoSfondoAttivo']
  .forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener('change', aggiornaStileDaToolbar);
    el.addEventListener('input', aggiornaStileDaToolbar); // i selettori colore nativi a volte confermano solo su 'input', non su 'change'
  });
aggiornaStileDaToolbar();

document.getElementById('disegnoAnnulla').addEventListener('click', () => Disegno.annullaUltimo());
document.getElementById('disegnoElimina').addEventListener('click', () => {
  if (!Disegno.haSelezione()) { alert('Seleziona prima una forma con lo strumento "Sposta" (clicca sopra al disegno).'); return; }
  Disegno.eliminaSelezionata();
});
document.getElementById('disegnoCancella').addEventListener('click', () => Disegno.cancellaTutto());

// ============================================================
// VISTA GIOCATORI: squadre per categoria + rosa (nome, cognome, ruolo, numero)
// ============================================================
const elencoSquadreGiocatoriEl = document.getElementById('elencoSquadreGiocatori');
const rosaSquadraTitolo = document.getElementById('rosaSquadraTitolo');
const nuovoGiocatoreForm = document.getElementById('nuovoGiocatoreForm');
const tabellaRosa = document.getElementById('tabellaRosa');

let squadraApertaInGiocatoriId = null;

async function caricaVistaGiocatori() {
  const squadre = await window.api.elencoSquadre();
  elencoSquadreGiocatoriEl.innerHTML = '';

  squadre.forEach(sq => {
    const riga = document.createElement('div');
    riga.className = 'squadra-riga-giocatori';
    riga.innerHTML = `
      <span>${sq.nome}${sq.categoria ? `<span class="categoria-label">${sq.categoria}</span>` : ''}</span>
      <span>${sq.n_giocatori} <button class="elimina-squadra" title="Elimina squadra">✕</button></span>
    `;
    riga.querySelector('.elimina-squadra').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`Eliminare "${sq.nome}"${sq.categoria ? ' (' + sq.categoria + ')' : ''} e tutta la sua rosa?`)) return;
      await window.api.eliminaSquadra(sq.id);
      if (squadraApertaInGiocatoriId === sq.id) { squadraApertaInGiocatoriId = null; nuovoGiocatoreForm.style.display = 'none'; tabellaRosa.innerHTML = ''; rosaSquadraTitolo.textContent = 'Seleziona una squadra'; }
      caricaVistaGiocatori();
    });
    riga.addEventListener('click', () => apriRosaSquadra(sq, riga));
    elencoSquadreGiocatoriEl.appendChild(riga);
  });
}

document.getElementById('btnNuovaSquadra').addEventListener('click', async () => {
  const nome = document.getElementById('nsNome').value.trim();
  const categoria = document.getElementById('nsCategoria').value.trim();
  if (!nome) { alert('Il nome squadra è obbligatorio.'); return; }

  await window.api.creaSquadra({ nome, categoria: categoria || null });
  document.getElementById('nsNome').value = '';
  document.getElementById('nsCategoria').value = '';
  caricaVistaGiocatori();
});

async function apriRosaSquadra(sq, rigaEl) {
  document.querySelectorAll('.squadra-riga-giocatori').forEach(r => r.classList.remove('attiva'));
  if (rigaEl) rigaEl.classList.add('attiva');

  squadraApertaInGiocatoriId = sq.id;
  rosaSquadraTitolo.textContent = `${sq.nome}${sq.categoria ? ' — ' + sq.categoria : ''}`;
  nuovoGiocatoreForm.style.display = 'flex';

  await renderizzaRosa();
}

async function renderizzaRosa() {
  const giocatori = await window.api.elencoGiocatoriPerSquadra(squadraApertaInGiocatoriId);
  tabellaRosa.innerHTML = '';

  giocatori.forEach(g => {
    const riga = document.createElement('div');
    riga.className = 'rosa-riga';
    riga.innerHTML = `
      <span class="numero">${g.numero || '-'}</span>
      <span>${g.nome} ${g.cognome || ''}</span>
      <span class="ruolo">${g.ruolo || ''}</span>
      <button class="elimina-giocatore" title="Rimuovi">✕</button>
      <span style="color:var(--muted); font-size:11px;">🔎</span>
    `;
    riga.querySelector('.elimina-giocatore').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`Rimuovere ${g.nome} ${g.cognome || ''} dalla rosa?`)) return;
      await window.api.eliminaGiocatore(g.id);
      renderizzaRosa();
      caricaVistaGiocatori();
    });
    riga.addEventListener('click', () => apriEventiGiocatore(g));
    tabellaRosa.appendChild(riga);
  });
}

document.getElementById('btnAggiungiGiocatore').addEventListener('click', async () => {
  if (!squadraApertaInGiocatoriId) return;
  const nome = document.getElementById('ngNome').value.trim();
  const cognome = document.getElementById('ngCognome').value.trim();
  const ruolo = document.getElementById('ngRuolo').value.trim();
  const numero = document.getElementById('ngNumero').value;

  if (!nome) { alert('Il nome è obbligatorio.'); return; }

  await window.api.creaGiocatore({
    squadra_id: squadraApertaInGiocatoriId,
    nome, cognome: cognome || null, ruolo: ruolo || null,
    numero: numero ? Number(numero) : null
  });

  document.getElementById('ngNome').value = '';
  document.getElementById('ngCognome').value = '';
  document.getElementById('ngRuolo').value = '';
  document.getElementById('ngNumero').value = '';

  await renderizzaRosa();
  caricaVistaGiocatori();
});

// ============================================================
// EVENTI DEL GIOCATORE: apri dal click su una riga della rosa,
// filtra per tag (es. "tutti i tiri da ala") e importa in presentazione
// ============================================================
const modalEventiGiocatore = document.getElementById('modalEventiGiocatore');
const titoloEventiGiocatore = document.getElementById('titoloEventiGiocatore');
const filtroTagEventiGiocatoreEl = document.getElementById('filtroTagEventiGiocatore');
const listaEventiGiocatoreEl = document.getElementById('listaEventiGiocatore');
const btnImportaEventiGiocatore = document.getElementById('btnImportaEventiGiocatore');

let eventiGiocatoreCorrente = [];
let eventiSelezionatiGiocatore = new Set();
let tagFiltroEventiGiocatore = new Set();

async function apriEventiGiocatore(g) {
  titoloEventiGiocatore.textContent = `Eventi di ${g.nome} ${g.cognome || ''}`;
  eventiSelezionatiGiocatore.clear();
  tagFiltroEventiGiocatore.clear();
  btnImportaEventiGiocatore.disabled = true;

  eventiGiocatoreCorrente = await window.api.eventiGiocatore(g.id);
  await caricaPannelloTag(filtroTagEventiGiocatoreEl, renderizzaListaEventiGiocatore, tagFiltroEventiGiocatore);
  renderizzaListaEventiGiocatore();

  modalEventiGiocatore.classList.add('active');
}

function renderizzaListaEventiGiocatore() {
  const filtrati = tagFiltroEventiGiocatore.size === 0
    ? eventiGiocatoreCorrente
    : eventiGiocatoreCorrente.filter(ev => {
        const idTagEvento = new Set(ev.tag.map(t => t.id));
        return [...tagFiltroEventiGiocatore].every(id => idTagEvento.has(id));
      });

  listaEventiGiocatoreEl.innerHTML = '';

  if (filtrati.length === 0) {
    listaEventiGiocatoreEl.innerHTML = '<p style="color:var(--muted); font-size:12px;">Nessun evento con questi tag per questo giocatore.</p>';
    return;
  }

  filtrati.forEach(ev => {
    const riga = document.createElement('div');
    riga.className = 'eventi-giocatore-riga';
    const badge = ev.tag.map(t => `<span class="tag-badge">${t.nome}</span>`).join('');
    riga.innerHTML = `
      <input type="checkbox">
      <span class="partita-label">${ev.squadra_casa} - ${ev.squadra_ospite}</span>
      <span class="tempo">${formatTime(ev.inizio_sec)}-${formatTime(ev.fine_sec)}</span>
      <span>${badge}</span>
    `;
    riga.querySelector('input').addEventListener('change', (e) => {
      if (e.target.checked) eventiSelezionatiGiocatore.add(ev.id); else eventiSelezionatiGiocatore.delete(ev.id);
      btnImportaEventiGiocatore.disabled = eventiSelezionatiGiocatore.size === 0;
    });
    listaEventiGiocatoreEl.appendChild(riga);
  });
}

document.getElementById('chiudiEventiGiocatore').addEventListener('click', () => {
  modalEventiGiocatore.classList.remove('active');
});

btnImportaEventiGiocatore.addEventListener('click', () => {
  apriModaleImporta({
    eventiSet: eventiSelezionatiGiocatore,
    dopoImport: () => {
      btnImportaEventiGiocatore.disabled = true;
      modalEventiGiocatore.classList.remove('active');
    }
  });
});

// ============================================================
// VISTA IMPOSTAZIONI: gestione tag — ogni coach personalizza il proprio pannello
// ============================================================
async function caricaVistaImpostazioni() {
  const categorie = await window.api.getTagsPerGestione();
  const cont = document.getElementById('gestioneCategorie');
  cont.innerHTML = '';

  categorie.forEach((cat, indiceCat) => {
    const blocco = document.createElement('div');
    blocco.className = 'gestione-categoria-blocco';
    blocco.innerHTML = `
      <div class="gestione-categoria-header">
        <input type="checkbox" ${cat.attiva ? 'checked' : ''} class="cat-toggle">
        <input type="text" class="cat-nome-input" value="${cat.nome}">
        <select class="cat-gruppo-select">
          <option value="generale" ${cat.gruppo === 'generale' || !cat.gruppo ? 'selected' : ''}>Generale</option>
          <option value="attacco" ${cat.gruppo === 'attacco' ? 'selected' : ''}>Attacco</option>
          <option value="difesa" ${cat.gruppo === 'difesa' ? 'selected' : ''}>Difesa</option>
        </select>
        <span class="ordina-gruppo">
          <button class="ordina-btn cat-su" ${indiceCat === 0 ? 'disabled' : ''} title="Sposta su">▲</button>
          <button class="ordina-btn cat-giu" ${indiceCat === categorie.length - 1 ? 'disabled' : ''} title="Sposta giù">▼</button>
        </span>
        <button class="cat-elimina" title="Elimina questa categoria (e tutto il suo contenuto)">🗑</button>
      </div>
      <div class="gestione-tag-lista"></div>
    `;

    blocco.querySelector('.cat-toggle').addEventListener('change', async (e) => {
      await window.api.toggleAttivaCategoria({ id: cat.id, attiva: e.target.checked });
    });
    const salvaNomeCat = async () => {
      const nome = blocco.querySelector('.cat-nome-input').value.trim();
      const gruppo = blocco.querySelector('.cat-gruppo-select').value;
      if (!nome) return;
      await window.api.rinominaCategoria({ id: cat.id, nome, gruppo });
    };
    blocco.querySelector('.cat-nome-input').addEventListener('blur', salvaNomeCat);
    blocco.querySelector('.cat-nome-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') e.target.blur(); });
    blocco.querySelector('.cat-gruppo-select').addEventListener('change', salvaNomeCat);

    blocco.querySelector('.cat-su').addEventListener('click', async () => {
      await window.api.spostaOrdineCategoria({ id: cat.id, direzione: 'su' });
      caricaVistaImpostazioni();
    });
    blocco.querySelector('.cat-giu').addEventListener('click', async () => {
      await window.api.spostaOrdineCategoria({ id: cat.id, direzione: 'giu' });
      caricaVistaImpostazioni();
    });
    blocco.querySelector('.cat-elimina').addEventListener('click', async () => {
      if (!confirm(`Eliminare tutta la categoria "${cat.nome}" con tutto il suo contenuto? Non si può annullare.`)) return;
      await window.api.eliminaCategoria(cat.id);
      caricaVistaImpostazioni();
    });

    const cartelleDisponibili = raccogliCartelle(cat.tag);
    const altreCategorie = categorie.filter(c => c.id !== cat.id).map(c => ({ id: c.id, nome: c.nome }));
    const listaTag = blocco.querySelector('.gestione-tag-lista');
    cat.tag.forEach((nodo, i) => renderizzaNodoGestione(nodo, listaTag, cat.id, cat.tag.length, i, cartelleDisponibili, altreCategorie));
    listaTag.appendChild(creaMiniFormAggiungiTag(cat.id, null));

    cont.appendChild(blocco);
  });
}

// Raccoglie tutte le cartelle di una categoria (a qualsiasi profondità),
// con un'etichetta leggibile del percorso, per popolare il menu "Sposta in"
function raccogliCartelle(nodi, prefisso = '') {
  let risultato = [];
  nodi.forEach(n => {
    if (n.e_cartella) {
      const etichetta = prefisso + n.nome;
      risultato.push({ id: n.id, etichetta });
      risultato = risultato.concat(raccogliCartelle(n.children, etichetta + ' › '));
    }
  });
  return risultato;
}

// Renderizza UN nodo nell'editor di gestione (tag o cartella): nome
// editabile, attivo/disattivo, ▲▼ tra fratelli, menu "sposta in" verso
// un'altra cartella della stessa categoria, ed eliminazione. Se è una
// cartella, mostra anche i figli annidati sotto e un mini-form per
// aggiungerne di nuovi dentro quella cartella specifica.
function renderizzaNodoGestione(nodo, contenitore, categoriaId, numFratelli, indice, cartelleDisponibili, altreCategorie) {
  const riga = document.createElement('div');
  riga.className = 'gestione-tag-riga' + (nodo.e_cartella ? ' gestione-cartella-riga' : '');

  const opzioniSposta = cartelleDisponibili
    .filter(c => c.id !== nodo.id)
    .map(c => `<option value="cartella:${c.id}" ${c.id === nodo.genitore_id ? 'selected' : ''}>${c.etichetta}</option>`)
    .join('');

  const opzioniAltreCategorie = (altreCategorie || [])
    .map(c => `<option value="categoria:${c.id}">${c.nome}</option>`)
    .join('');

  riga.innerHTML = `
    <input type="checkbox" ${nodo.attivo ? 'checked' : ''}>
    ${nodo.e_cartella ? '<span>📁</span>' : ''}
    <input type="text" class="nodo-nome-input" value="${nodo.nome}">
    ${!nodo.e_cartella ? `<input type="color" class="nodo-colore-input" value="${nodo.colore || '#8899aa'}" title="Colore">` : ''}
    <select class="nodo-sposta-in" title="Sposta qui dentro o in un'altra categoria">
      <option value="qui" ${!nodo.genitore_id ? 'selected' : ''}>— primo livello (qui) —</option>
      ${opzioniSposta}
      ${opzioniAltreCategorie ? `<optgroup label="Sposta in un'altra categoria">${opzioniAltreCategorie}</optgroup>` : ''}
    </select>
    <span class="ordina-gruppo">
      <button class="ordina-btn nodo-su" ${indice === 0 ? 'disabled' : ''} title="Sposta su">▲</button>
      <button class="ordina-btn nodo-giu" ${indice === numFratelli - 1 ? 'disabled' : ''} title="Sposta giù">▼</button>
    </span>
    <button class="nodo-elimina" title="Elimina${nodo.e_cartella ? ' (e tutto il contenuto dentro)' : ''}">🗑</button>
  `;

  riga.querySelector('input[type="checkbox"]').addEventListener('change', async (e) => {
    await window.api.toggleAttivoTag({ id: nodo.id, attivo: e.target.checked });
  });

  const salvaNodo = async () => {
    const nome = riga.querySelector('.nodo-nome-input').value.trim();
    if (!nome) return;
    const coloreInput = riga.querySelector('.nodo-colore-input');
    await window.api.rinominaTag({ id: nodo.id, nome, colore: coloreInput ? coloreInput.value : null });
  };
  riga.querySelector('.nodo-nome-input').addEventListener('blur', salvaNodo);
  riga.querySelector('.nodo-nome-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') e.target.blur(); });
  const coloreInput = riga.querySelector('.nodo-colore-input');
  if (coloreInput) coloreInput.addEventListener('change', salvaNodo);

  riga.querySelector('.nodo-sposta-in').addEventListener('change', async (e) => {
    const valore = e.target.value;
    const payload = { id: nodo.id };
    if (valore.startsWith('categoria:')) {
      payload.categoria_id = Number(valore.split(':')[1]);
      payload.genitore_id = null;
    } else if (valore.startsWith('cartella:')) {
      payload.genitore_id = Number(valore.split(':')[1]);
    } else {
      payload.genitore_id = null; // "qui", primo livello della categoria attuale
    }
    await window.api.spostaGenitoreTag(payload);
    caricaVistaImpostazioni();
  });

  riga.querySelector('.nodo-su').addEventListener('click', async () => {
    await window.api.spostaOrdineTag({ id: nodo.id, direzione: 'su' });
    caricaVistaImpostazioni();
  });
  riga.querySelector('.nodo-giu').addEventListener('click', async () => {
    await window.api.spostaOrdineTag({ id: nodo.id, direzione: 'giu' });
    caricaVistaImpostazioni();
  });
  riga.querySelector('.nodo-elimina').addEventListener('click', async () => {
    const avviso = nodo.e_cartella
      ? `Eliminare la cartella "${nodo.nome}" e tutto quello che contiene dentro?`
      : `Eliminare "${nodo.nome}"?`;
    if (!confirm(avviso)) return;
    await window.api.eliminaTag(nodo.id);
    caricaVistaImpostazioni();
  });

  contenitore.appendChild(riga);

  if (nodo.e_cartella) {
    const figliWrap = document.createElement('div');
    figliWrap.className = 'gestione-tag-figli';
    nodo.children.forEach((figlio, i) => renderizzaNodoGestione(figlio, figliWrap, categoriaId, nodo.children.length, i, cartelleDisponibili, altreCategorie));
    figliWrap.appendChild(creaMiniFormAggiungiTag(categoriaId, nodo.id));
    contenitore.appendChild(figliWrap);
  }
}

// Form per aggiungere una voce (tag o cartella) dentro una categoria o
// dentro una cartella specifica (genitoreId nullo = primo livello)
function creaMiniFormAggiungiTag(categoriaId, genitoreId) {
  const form = document.createElement('div');
  form.className = 'nuovo-tag-form';
  form.innerHTML = `
    <input type="text" placeholder="${genitoreId ? 'Nuova voce qui dentro' : 'Nuovo tag in questa categoria'}" class="nt-nome">
    <label class="nt-cartella-label"><input type="checkbox" class="nt-cartella"> Cartella</label>
    <input type="color" class="nt-colore" value="#8899aa" title="Colore (opzionale)">
    <button class="nt-aggiungi">+ Aggiungi</button>
  `;

  form.querySelector('.nt-aggiungi').addEventListener('click', async () => {
    const nomeInput = form.querySelector('.nt-nome');
    const nome = nomeInput.value.trim();
    if (!nome) return;
    const eCartella = form.querySelector('.nt-cartella').checked;
    const colore = form.querySelector('.nt-colore').value;

    await window.api.creaTag({
      categoria_id: categoriaId,
      genitore_id: genitoreId,
      nome,
      colore: eCartella ? null : colore,
      e_cartella: eCartella
    });
    caricaVistaImpostazioni();
  });

  return form;
}

document.getElementById('btnNuovaCategoria').addEventListener('click', async () => {
  const nomeInput = document.getElementById('ncNome');
  const nome = nomeInput.value.trim();
  const gruppo = document.getElementById('ncGruppo').value;
  if (!nome) { alert('Dai un nome alla categoria.'); return; }

  await window.api.creaCategoria({ nome, gruppo });
  nomeInput.value = '';
  caricaVistaImpostazioni();
});

// ============================================================
// VISTA IMPOSTAZIONI (Account, Abbonamento, Video, Privacy, Supporto, Info)
// App interamente locale: nessun server, nessun login, nessun pagamento.
// Le sezioni che richiederebbero un backend cloud sono segnalate come tali
// invece di mostrare dati finti.
// ============================================================
let sezioneImpostazioniAttiva = 'account';
let impostazioniAppCache = {};

async function caricaVistaImpostazioniApp() {
  impostazioniAppCache = await window.api.leggiImpostazioniApp();

  document.querySelectorAll('.impostazioni-sezione-btn').forEach(btn => {
    btn.classList.toggle('attiva', btn.dataset.sezione === sezioneImpostazioniAttiva);
    btn.onclick = () => {
      sezioneImpostazioniAttiva = btn.dataset.sezione;
      document.querySelectorAll('.impostazioni-sezione-btn').forEach(b => b.classList.remove('attiva'));
      btn.classList.add('attiva');
      renderizzaSezioneImpostazioni();
    };
  });

  renderizzaSezioneImpostazioni();
}

function renderizzaSezioneImpostazioni() {
  const cont = document.getElementById('impostazioniAppContenuto');
  if (sezioneImpostazioniAttiva === 'account') return renderizzaSezioneAccount(cont);
  if (sezioneImpostazioniAttiva === 'abbonamento') return renderizzaSezioneAbbonamento(cont);
  if (sezioneImpostazioniAttiva === 'video') return renderizzaSezioneVideo(cont);
  if (sezioneImpostazioniAttiva === 'privacy') return renderizzaSezionePrivacy(cont);
  if (sezioneImpostazioniAttiva === 'supporto') return renderizzaSezioneSupporto(cont);
  if (sezioneImpostazioniAttiva === 'info') return renderizzaSezioneInfo(cont);
}

function renderizzaSezioneAccount(cont) {
  cont.innerHTML = `
    <h2>👤 Account</h2>
    <span class="badge-locale">Versione locale — nessun account online</span>
    <div class="campo-impostazione">
      <label>Nome coach</label>
      <span class="desc">Usato per identificarti nelle esportazioni future. Salvato solo su questo Mac.</span>
      <input type="text" id="accNomeCoach" placeholder="Es. Salvatore Onelli" value="${impostazioniAppCache.nome_coach || ''}">
    </div>
    <div class="campo-impostazione">
      <label>Email</label>
      <input type="email" disabled placeholder="richiede un account REVOS online">
      <span class="nota-non-disponibile">Non disponibile in questa versione locale</span>
    </div>
    <div class="campo-impostazione">
      <label>Foto</label>
      <span class="nota-non-disponibile">Non disponibile in questa versione locale</span>
    </div>
    <div class="campo-impostazione">
      <label>Password</label>
      <input type="password" disabled placeholder="••••••••">
      <span class="nota-non-disponibile">Non disponibile in questa versione locale</span>
    </div>
    <div class="campo-impostazione">
      <label>Lingua</label>
      <select disabled><option>Italiano</option></select>
      <span class="desc">L'app è disponibile solo in italiano per ora.</span>
    </div>
    <div class="campo-impostazione">
      <button class="btn-impostazione" disabled>Esci (logout)</button>
      <span class="nota-non-disponibile">Non applicabile: non hai eseguito l'accesso a nessun account</span>
    </div>
  `;

  document.getElementById('accNomeCoach').addEventListener('blur', async (e) => {
    const valore = e.target.value.trim();
    await window.api.scriviImpostazioneApp({ chiave: 'nome_coach', valore });
    impostazioniAppCache.nome_coach = valore;
    document.getElementById('statoSalvataggio').textContent = 'Nome salvato';
  });
}

function renderizzaSezioneAbbonamento(cont) {
  cont.innerHTML = `
    <h2>💳 Abbonamento</h2>
    <span class="badge-locale">Versione locale</span>
    <p class="sotto-intro">
      Questa è la versione locale di Handball Analyst: gira interamente sul tuo Mac, senza abbonamenti né pagamenti.
      Tutte le funzionalità sono incluse. Se in futuro arriverà una versione REVOS con servizi cloud
      (sincronizzazione multi-coach, backup online), qui troverai piano, rinnovo, fatture e metodo di pagamento.
    </p>
  `;
}

function renderizzaSezioneVideo(cont) {
  const cartella = impostazioniAppCache.cartella_video_predefinita || '';
  const proxyAttivo = impostazioniAppCache.proxy_attivo === '1';
  const proxyQualita = impostazioniAppCache.proxy_qualita || 'media';
  const exportPreset = impostazioniAppCache.export_preset || 'veryfast';
  const percorsoLabel = cartella || "nessuna impostata (si parte dall'ultima cartella aperta)";

  cont.innerHTML = `
    <h2>🎥 Video</h2>

    <div class="campo-impostazione">
      <label>Cartella video predefinita</label>
      <span class="desc">Punto di partenza quando selezioni un video per una nuova partita.</span>
      <div class="riga-azione">
        <button class="btn-impostazione" id="videoCambiaCartella">Cambia cartella…</button>
        <span class="percorso-attuale">${percorsoLabel}</span>
      </div>
    </div>

    <div class="campo-impostazione">
      <label><input type="checkbox" id="videoProxyAttivo" ${proxyAttivo ? 'checked' : ''}> Genera proxy automaticamente</label>
      <span class="desc">Copia leggera a bassa risoluzione per lavorare più fluido durante l'analisi. <strong>Non ancora attiva in questa versione</strong> — la preferenza viene salvata, la generazione arriverà in un prossimo aggiornamento.</span>
      <select id="videoProxyQualita" ${!proxyAttivo ? 'disabled' : ''}>
        <option value="bassa" ${proxyQualita === 'bassa' ? 'selected' : ''}>Qualità bassa (più veloce)</option>
        <option value="media" ${proxyQualita === 'media' ? 'selected' : ''}>Qualità media</option>
        <option value="alta" ${proxyQualita === 'alta' ? 'selected' : ''}>Qualità alta</option>
      </select>
    </div>

    <div class="campo-impostazione">
      <label>Cache export</label>
      <span class="desc">File temporanei creati durante l'esportazione delle presentazioni.</span>
      <div class="riga-azione">
        <span class="percorso-attuale" id="cacheInfo">calcolo in corso…</span>
        <button class="btn-impostazione pericolo" id="btnSvuotaCache">Svuota cache</button>
      </div>
    </div>

    <div class="campo-impostazione">
      <label>Qualità esportazione</label>
      <span class="desc">Compromesso velocità/qualità per i video esportati dalle presentazioni.</span>
      <select id="videoExportPreset">
        <option value="ultrafast" ${exportPreset === 'ultrafast' ? 'selected' : ''}>Più veloce (file più pesante)</option>
        <option value="veryfast" ${exportPreset === 'veryfast' ? 'selected' : ''}>Veloce (consigliato)</option>
        <option value="medium" ${exportPreset === 'medium' ? 'selected' : ''}>Bilanciato</option>
        <option value="slow" ${exportPreset === 'slow' ? 'selected' : ''}>Qualità migliore (più lento)</option>
      </select>
    </div>
  `;

  document.getElementById('videoCambiaCartella').addEventListener('click', async () => {
    const cartellaScelta = await window.api.sceglieCartellaVideo();
    if (!cartellaScelta) return;
    await window.api.scriviImpostazioneApp({ chiave: 'cartella_video_predefinita', valore: cartellaScelta });
    impostazioniAppCache.cartella_video_predefinita = cartellaScelta;
    renderizzaSezioneVideo(cont);
  });

  document.getElementById('videoProxyAttivo').addEventListener('change', async (e) => {
    await window.api.scriviImpostazioneApp({ chiave: 'proxy_attivo', valore: e.target.checked ? '1' : '0' });
    impostazioniAppCache.proxy_attivo = e.target.checked ? '1' : '0';
    renderizzaSezioneVideo(cont);
  });
  document.getElementById('videoProxyQualita').addEventListener('change', async (e) => {
    await window.api.scriviImpostazioneApp({ chiave: 'proxy_qualita', valore: e.target.value });
    impostazioniAppCache.proxy_qualita = e.target.value;
  });
  document.getElementById('videoExportPreset').addEventListener('change', async (e) => {
    await window.api.scriviImpostazioneApp({ chiave: 'export_preset', valore: e.target.value });
    impostazioniAppCache.export_preset = e.target.value;
  });

  window.api.dimensioneCache().then(({ byte, numeroCartelle }) => {
    const mb = (byte / (1024 * 1024)).toFixed(1);
    const info = document.getElementById('cacheInfo');
    if (info) info.textContent = `${mb} MB in ${numeroCartelle} cartelle temporanee`;
  });

  document.getElementById('btnSvuotaCache').addEventListener('click', async () => {
    await window.api.svuotaCache();
    document.getElementById('statoSalvataggio').textContent = 'Cache svuotata';
    renderizzaSezioneVideo(cont);
  });
}

function renderizzaSezionePrivacy(cont) {
  cont.innerHTML = `
    <h2>🔐 Privacy &amp; Sicurezza</h2>
    <span class="badge-locale">Versione locale</span>

    <div class="campo-impostazione">
      <label>Password</label>
      <span class="nota-non-disponibile">Non applicabile: nessun account online in questa versione</span>
    </div>
    <div class="campo-impostazione">
      <label>Dispositivi collegati / Sessioni</label>
      <span class="nota-non-disponibile">Richiede un account REVOS online — non disponibile in locale</span>
    </div>
    <div class="campo-impostazione">
      <label>Dove sono i tuoi dati</label>
      <span class="desc">Partite, tag, giocatori e presentazioni restano solo su questo Mac, in un database locale. Nessun dato viene inviato a server esterni.</span>
    </div>
    <div class="campo-impostazione">
      <label>Elimina tutti i dati locali</label>
      <span class="desc">Cancella per sempre partite, eventi, giocatori, presentazioni e tag personalizzati. I tag tornano ai valori di default.</span>
      <div class="riga-azione">
        <button class="btn-impostazione pericolo" id="btnEliminaDatiLocali">🗑 Elimina tutti i dati locali</button>
      </div>
    </div>
  `;

  document.getElementById('btnEliminaDatiLocali').addEventListener('click', () => {
    document.getElementById('resetConfermaInput').value = '';
    document.getElementById('modalConfermaReset').classList.add('active');
  });
}

function renderizzaSezioneSupporto(cont) {
  cont.innerHTML = `
    <h2>❓ Supporto</h2>
    <div class="campo-impostazione">
      <label>Guida</label>
      <span class="desc">In arrivo.</span>
    </div>
    <div class="campo-impostazione">
      <label>Tutorial</label>
      <span class="desc">In arrivo.</span>
    </div>
    <div class="campo-impostazione">
      <label>Contatta assistenza</label>
      <span class="desc">Da configurare quando avrai un indirizzo email di supporto dedicato.</span>
    </div>
    <div class="campo-impostazione">
      <label>Segnala un problema</label>
      <span class="desc">In arrivo.</span>
    </div>
  `;
}

function renderizzaSezioneInfo(cont) {
  cont.innerHTML = `
    <h2>ℹ️ Informazioni</h2>
    <div class="campo-impostazione">
      <label>Versione REVOS Handball Analyst</label>
      <span class="desc" id="infoVersione">caricamento…</span>
    </div>
    <div class="campo-impostazione">
      <label>Aggiornamenti</label>
      <span class="nota-non-disponibile">Controllo automatico non disponibile in questa versione locale</span>
    </div>
    <div class="campo-impostazione">
      <label>Licenze open source</label>
      <ul class="lista-licenze">
        <li>Electron</li>
        <li>better-sqlite3</li>
        <li>ffmpeg-static / FFmpeg</li>
        <li>fluent-ffmpeg</li>
      </ul>
    </div>
    <div class="campo-impostazione">
      <label>Termini e Privacy</label>
      <span class="desc">In preparazione.</span>
    </div>
  `;

  window.api.versioneApp().then(v => {
    const el = document.getElementById('infoVersione');
    if (el) el.textContent = `v${v}`;
  });
}

// --- Conferma eliminazione dati locali ---
document.getElementById('resetAnnulla').addEventListener('click', () => {
  document.getElementById('modalConfermaReset').classList.remove('active');
});
document.getElementById('resetConferma').addEventListener('click', async () => {
  const testo = document.getElementById('resetConfermaInput').value.trim();
  if (testo !== 'ELIMINA') { alert('Scrivi ELIMINA (tutto maiuscolo) per confermare.'); return; }

  await window.api.eliminaTuttiDatiLocali();
  document.getElementById('modalConfermaReset').classList.remove('active');

  // ricarico l'intera app: è il modo più sicuro per azzerare tutte le
  // variabili in memoria delle altre viste dopo un reset totale dei dati
  location.reload();
});
